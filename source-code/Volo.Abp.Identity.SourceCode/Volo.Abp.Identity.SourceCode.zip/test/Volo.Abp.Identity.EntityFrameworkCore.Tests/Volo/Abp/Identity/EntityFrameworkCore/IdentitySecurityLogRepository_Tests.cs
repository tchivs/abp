﻿namespace Volo.Abp.Identity.EntityFrameworkCore;

public class IdentitySecurityLogRepository_Tests : IdentitySecurityLogRepository_Tests<AbpIdentityEntityFrameworkCoreTestModule>
{

}
