﻿namespace Volo.Abp.Identity;

public class IdentityDataSeedResult
{
    public bool CreatedAdminUser { get; set; }

    public bool CreatedAdminRole { get; set; }
}
