// This file is part of ProfileClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Abp.Account;

public partial class ProfileClientProxy
{
}
