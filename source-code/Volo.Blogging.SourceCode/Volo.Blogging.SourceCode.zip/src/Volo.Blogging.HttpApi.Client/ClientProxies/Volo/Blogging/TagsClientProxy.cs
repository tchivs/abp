// This file is part of TagsClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Blogging;

public partial class TagsClientProxy
{
}
