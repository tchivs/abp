namespace Volo.Blogging.Admin;

public class BloggingAdminMenuNames
{
    public const string GroupName = "BlogManagement";
    
    public const string Blogs = GroupName + ".Blogs";
}