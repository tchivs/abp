﻿namespace Volo.Blogging
{
    public static class BloggingRemoteServiceConsts
    {
        public const string RemoteServiceName = "Blogging";

        public const string ModuleName = "blogging";
    }
}
