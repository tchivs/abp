﻿namespace Volo.ClientSimulation;

public enum SimulationState
{
    Stopped,
    Starting,
    Started,
    Stopping
}
