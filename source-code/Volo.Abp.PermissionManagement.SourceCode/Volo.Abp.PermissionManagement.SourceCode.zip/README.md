# abp-permissionmanagement
Permission management module for ABP framework.
