﻿namespace Volo.Abp.SettingManagement.EntityFrameworkCore;

public class SettingRepository_Tests : SettingRepository_Tests<AbpSettingManagementEntityFrameworkCoreTestModule>
{

}
