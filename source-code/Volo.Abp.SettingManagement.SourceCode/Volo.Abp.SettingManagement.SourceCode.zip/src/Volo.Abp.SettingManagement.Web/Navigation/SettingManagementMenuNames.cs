﻿namespace Volo.Abp.SettingManagement.Web.Navigation;

public class SettingManagementMenuNames
{
    public const string GroupName = "SettingManagement";
}
