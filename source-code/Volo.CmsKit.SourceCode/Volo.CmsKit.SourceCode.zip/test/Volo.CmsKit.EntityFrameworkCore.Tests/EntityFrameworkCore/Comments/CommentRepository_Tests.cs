﻿using Volo.CmsKit.Comments;

namespace Volo.CmsKit.EntityFrameworkCore.Comments;

public class CommentRepository_Tests : CommentRepository_Tests<CmsKitEntityFrameworkCoreTestModule>
{

}
