﻿namespace Volo.CmsKit.Contents;
public static class ContentConsts
{
    public static string Delimeter { get; set; } = "----";
    public static string Widget { get; set; } = "Widget";
    public static string Markdown { get; set; } = "Markdown";
    public static string Content { get; set; } = "Content";
}
