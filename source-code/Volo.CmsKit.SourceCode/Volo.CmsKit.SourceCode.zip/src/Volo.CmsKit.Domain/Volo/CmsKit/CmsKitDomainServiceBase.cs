﻿using Volo.Abp.Domain.Services;

namespace Volo.CmsKit;

public abstract class CmsKitDomainServiceBase : DomainService
{

}
