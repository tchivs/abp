﻿namespace Volo.CmsKit.Entities;

public class CmsEntityConsts
{
    public static int MaxEntityTypeLength { get; set; } = 64;

    public static int MaxEntityIdLength { get; set; } = 64;
}
