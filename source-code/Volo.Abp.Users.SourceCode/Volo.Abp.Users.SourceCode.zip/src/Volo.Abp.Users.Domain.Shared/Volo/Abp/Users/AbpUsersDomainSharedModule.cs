﻿using Volo.Abp.Modularity;

namespace Volo.Abp.Users;

public class AbpUsersDomainSharedModule : AbpModule
{

}
