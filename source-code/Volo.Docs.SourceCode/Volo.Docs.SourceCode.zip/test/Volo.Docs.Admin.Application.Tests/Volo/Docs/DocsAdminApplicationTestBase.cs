﻿namespace Volo.Docs
{
    public class DocsAdminApplicationTestBase : DocsTestBase<DocsAdminApplicationTestModule>
    {

    }
}
