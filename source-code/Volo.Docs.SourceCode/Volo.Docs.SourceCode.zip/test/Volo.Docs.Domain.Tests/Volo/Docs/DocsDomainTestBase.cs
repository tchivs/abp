﻿namespace Volo.Docs
{
    public abstract class DocsDomainTestBase : DocsTestBase<DocsDomainTestModule>
    {
        
    }
}
