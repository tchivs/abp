﻿using System;

namespace Volo.Docs.Admin.Projects;

public class ProjectWithoutDetailsDto
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}