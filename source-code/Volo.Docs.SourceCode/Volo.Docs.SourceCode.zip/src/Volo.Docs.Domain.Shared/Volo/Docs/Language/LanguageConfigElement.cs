﻿namespace Volo.Docs.Documents
{
    public class LanguageConfigElement
    {
        public string DisplayName { get; set; }

        public string Code { get; set; }

        public bool IsDefault { get; set; }
    }
}
