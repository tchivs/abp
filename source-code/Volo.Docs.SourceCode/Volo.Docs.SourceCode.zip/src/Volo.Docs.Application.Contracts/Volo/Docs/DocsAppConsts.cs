﻿namespace Volo.Docs
{
    public class DocsAppConsts
    {
        public static string Latest = "latest";
    }
}