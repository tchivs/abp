using System;

namespace Volo.Docs.Documents
{
    [Serializable]
    public class DocumentResourceDto
    {
        public byte[] Content { get; set; }
    }
}