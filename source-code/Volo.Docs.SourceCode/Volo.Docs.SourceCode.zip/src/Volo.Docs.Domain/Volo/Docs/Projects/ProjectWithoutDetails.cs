﻿using System;

namespace Volo.Docs.Projects;

public class ProjectWithoutDetails
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}