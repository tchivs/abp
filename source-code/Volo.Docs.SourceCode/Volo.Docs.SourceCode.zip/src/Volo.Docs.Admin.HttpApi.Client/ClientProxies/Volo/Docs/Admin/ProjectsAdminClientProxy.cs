// This file is part of ProjectsAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Docs.Admin;

public partial class ProjectsAdminClientProxy
{
}
