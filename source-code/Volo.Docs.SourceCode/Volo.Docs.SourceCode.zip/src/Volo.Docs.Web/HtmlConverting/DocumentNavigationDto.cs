namespace Volo.Docs.HtmlConverting;

public class DocumentNavigationDto
{
    public string Name { get; set; }
    public string Path { get; set; }
}