namespace Volo.Abp.OpenIddict;

public static class TestPermissionNames
{
    public static class Groups
    {
        public const string TestGroup = "TestGroup";
    }

    public const string MyPermission1 = "MyPermission1";

    public const string MyPermission2 = "MyPermission2";
}
