﻿using Xunit;

namespace Volo.Abp.OpenIddict.MongoDB;

[Collection(MongoTestCollection.Name)]
public class OpenIddictScopeRepository_Tests : OpenIddictScopeRepository_Tests<OpenIddictMongoDbTestModule>
{
    
}