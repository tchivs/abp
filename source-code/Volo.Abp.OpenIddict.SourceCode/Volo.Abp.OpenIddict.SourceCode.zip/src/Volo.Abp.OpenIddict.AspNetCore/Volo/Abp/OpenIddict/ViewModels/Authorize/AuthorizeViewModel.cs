﻿namespace Volo.Abp.OpenIddict.ViewModels.Authorization;

public class AuthorizeViewModel
{
    public string ApplicationName { get; set; }

    public string Scope { get; set; }
}
